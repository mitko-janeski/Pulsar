<html>
    <head>
        <title>Register - Adresar</title>
        
        <style type="text/css">
            .register-wrapper {
                width: 400px;
                height: 350px;
                border: 1px solid black;
                margin-top: 150px;
            }
            .register-center {
                margin-left: auto;
                margin-right: auto;
            }
            .register-title {
                width: 100px;
                margin-left: auto;
                margin-right: auto;
            }
            
            input {
               width: 100%;
               margin: 10px 0px 0px 0px;
               padding: 10px;
            }
        </style>
    </head>
    
    <body>
        <div class="register-wrapper register-center">
            <p class="register-title">Register Form</p>
            <form action="register_action.php" method="POST">
                <input type="text" name="username" value="" placeholder="Username"/> <br>
                <input type="password" name="password" value="" placeholder="Password"/> <br>
                <input type="password" name="password2" value="" placeholder="Password"/> <br>
                <input type="text" name="firstName" value="" placeholder="First Name"/> <br>
                <input type="text" name="lastName" value="" placeholder="Last Name"/> <br>
                <?php
                    if( isset($_GET['greska']) ) {
                        $greska = $_GET['greska'];
                        if($greska == 1) {
                            echo '<p style="color: red">Edno od polinata go izostavivte</p>';
                        } else if($greska == 2) {
                            echo '<p style="color: red">Ne se validni informaciite</p>';
                        } else if($greska == 3) {
                            echo '<p style="color: red">Vnesenite parametri se gresni</p>';
                        }
                    }
                ?>
                <input type="submit" value="Login"/>
            </form>
        </div>
    </body>
</html>