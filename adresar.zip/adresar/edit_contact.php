<?php

session_start();

if( isset($_SESSION['user']) ) {
    
} else {
    header('location: login.php'); exit;
}

$contactToEdit = null;
if( isset($_GET['contact_id']) ) {
    if( !empty($_GET['contact_id']) && is_numeric($_GET['contact_id']) ) {
        $link = mysqli_connect("localhost", "root", "", "adresar");

        $contact_id = mysqli_real_escape_string($link, $_GET['contact_id']);
        $query = "SELECT * FROM contacts WHERE contact_id=" . $contact_id;
        $result = mysqli_query($link, $query);
        $contactToEdit = mysqli_fetch_assoc($result);
    }
}

if( $contactToEdit == null ) {
    header('location: index.php'); exit;
}
?>
<html>
    <head>
        <title>Edit Contact - Adresar</title>
        
        <style type="text/css">
            .edit-wrapper {
                width: 400px;
                height: 350px;
                border: 1px solid black;
                margin-top: 150px;
            }
            .edit-center {
                margin-left: auto;
                margin-right: auto;
            }
            .edit-title {
                width: 150px;
                margin-left: auto;
                margin-right: auto;
            }
            
            input {
               width: 100%;
               margin: 10px 0px 0px 0px;
               padding: 10px;
            }
        </style>
    </head>
    
    <body>
        <div class="edit-wrapper edit-center">
            <p class="edit-title">Edit Contact Form</p>
            <form action="edit_contact_action.php" method="POST">
                <input type="text" name="firstName" value="<?php echo $contactToEdit['first_name']; ?>" placeholder="First Name"/> <br>
                <input type="text" name="lastName" value="<?php echo $contactToEdit['last_name']; ?>" placeholder="Last Name"/> <br>
                <input type="text" name="address" value="<?php echo $contactToEdit['address']; ?>" placeholder="Address"/> <br>
                <input type="hidden" name="contact_id" value="<?php echo $contactToEdit['contact_id']; ?>"/>
                <?php
                    if( isset($_GET['greska']) ) {
                        $greska = $_GET['greska'];
                        if($greska == 1) {
                            echo '<p style="color: red">Edno od polinata go izostavivte</p>';
                        } else if($greska == 2) {
                            echo '<p style="color: red">Ne se validni informaciite</p>';
                        } else if($greska == 3) {
                            echo '<p style="color: red">Vnesenite parametri se gresni</p>';
                        }
                    }
                ?>
                <input type="submit" value="Edit Contact"/>
            </form>
        </div>
    </body>
</html>