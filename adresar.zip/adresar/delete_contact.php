<?php

session_start();

if( isset($_SESSION['user']) ) {
    $user = $_SESSION['user'];
} else {
    header('location: login.php');
}
$contactId = filter_input(INPUT_GET, 'contact_id', FILTER_VALIDATE_INT);
if( $contactId ) {
    $link = mysqli_connect("localhost", "root", "", "adresar");

    $query = "DELETE FROM contacts WHERE contact_id=$contactId";
    mysqli_query($link, $query);
}
header("location: index.php");