<html>
    <head>
        <title>Login - Adresar</title>
        
        <style type="text/css">
            .login-wrapper {
                width: 400px;
                height: 250px;
                border: 1px solid black;
                margin-top: 250px;
            }
            .login-center {
                margin-left: auto;
                margin-right: auto;
            }
            .login-title {
                width: 100px;
                margin-left: auto;
                margin-right: auto;
            }
            
            input {
               width: 100%;
               margin: 10px 0px 0px 0px;
               padding: 10px;
            }
        </style>
    </head>
    
    <body>
        <div class="login-wrapper login-center">
            <p class="login-title">Login Form</p>
            <form action="login_action.php" method="POST">
                <input type="text" name="username" value="" placeholder="Username"/> <br>
                <input type="password" name="password" value="" placeholder="Password"/> <br>
                <?php
                    if( isset($_GET['greska']) ) {
                        $greska = $_GET['greska'];
                        if($greska == 1) {
                            echo '<p style="color: red">Edno od polinata go izostavivte</p>';
                        } else if($greska == 2) {
                            echo '<p style="color: red">Ne se validni informaciite</p>';
                        } else if($greska == 3) {
                            echo '<p style="color: red">Vnesenite parametri se gresni</p>';
                        }
                    }
                ?>
                <input type="submit" value="Login"/>
            </form>
        </div>
    </body>
</html>