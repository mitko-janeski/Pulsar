<?php

session_start();

if( isset($_SESSION['user']) ) {
    $user = $_SESSION['user'];
} else {
    header('location: login.php');
}

if( isset($_POST['firstName']) && isset($_POST['lastName']) 
        && isset($_POST['address']) && isset($_POST['contact_id']) ) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $address = $_POST['address'];
    $contactId = $_POST['contact_id'];
    
    if( !empty($firstName) && !empty($lastName) && !empty($address) && !empty($contactId) ) {
        if( strlen($firstName) >= 3 && strlen($lastName) >= 5 
                && strlen($address) >= 3 && is_numeric($contactId) ) {
            $link = mysqli_connect("localhost", "root", "", "adresar");
            
            $query = "UPDATE contacts SET first_name='$firstName', last_name='$lastName', address='$address' WHERE contact_id=$contactId";
            $result = mysqli_query($link, $query);
            if( $result ) {
                header("location: index.php");
            } else {
                header("location: edit_contact.php?greska=4&contact_id=$contactId");
            }
        } else {
           header("location: edit_contact.php?greska=2&contact_id=$contactId");
        }
    } else {
        header("location: edit_contact.php?greska=1&contact_id=$contactId");
    }
} else {
    echo "ne vnesivte potrebni informacii";
}