<?php

session_start();

if( isset($_SESSION['user']) ) {
    $user = $_SESSION['user'];
} else {
    header('location: login.php');
}

if( isset($_POST['firstName']) && isset($_POST['lastName']) 
        && isset($_POST['address']) ) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $address = $_POST['address'];
    
    if( !empty($firstName) && !empty($lastName) && !empty($address) ) {
        if( strlen($firstName) >= 3 && strlen($lastName) >= 5 
                && strlen($address) >= 3 ) {
            $link = mysqli_connect("localhost", "root", "", "adresar");
            
            $query = "INSERT INTO contacts (first_name, last_name, address, user_id)"
                    . " VALUES ('$firstName', '$lastName', '$address', ". $user['user_id'] .")";
            $result = mysqli_query($link, $query);
            if( $result ) {
                header("location: index.php");
            } else {
                header("location: add_contact.php?greska=4");
            }
        } else {
           header("location: add_contact.php?greska=2");
        }
    } else {
        header("location: add_contact.php?greska=1");
    }
} else {
    echo "ne vnesivte potrebni informacii";
}