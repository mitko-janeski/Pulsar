<?php

if( isset($_POST['username']) && isset($_POST['password'])
        && isset($_POST['password2']) && isset($_POST['firstName'])
        && isset($_POST['lastName']) ) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    
    if( !empty($username) && !empty($password) && !empty($password2)
            && !empty($firstName) && !empty($lastName) ) {
        if( strlen($username) >= 5 && strlen($password) >= 5
                && strlen($password2) >= 5 && strlen($firstName) >= 3
                && strlen($lastName) >= 5 && $password == $password2 ) {
            $link = mysqli_connect("localhost", "root", "", "adresar");
            
            $query = "SELECT * FROM users WHERE username='$username'";
            $result = mysqli_query($link, $query);
            $user = mysqli_fetch_assoc($result);
            if( is_null($user) ) {
                $query = "INSERT INTO users (username, password, first_name, last_name)"
                        . " VALUES ('$username', '$password', '$firstName', '$lastName')";
                $result = mysqli_query($link, $query);
                if( $result ) {
                    header("location: login.php");
                } else {
                    header("location: register.php?greska=4");
                }
            } else {
                header("location: register.php?greska=5");
            }
        } else {
           header("location: register.php?greska=2");
        }
    } else {
        header("location: register.php?greska=1");
    }
} else {
    echo "ne vnesivte potrebni informacii";
}