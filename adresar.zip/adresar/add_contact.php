<?php

session_start();

if( isset($_SESSION['user']) ) {
    
} else {
    header('location: login.php');
}
?>
<html>
    <head>
        <title>Add Contact - Adresar</title>
        
        <style type="text/css">
            .register-wrapper {
                width: 400px;
                height: 350px;
                border: 1px solid black;
                margin-top: 150px;
            }
            .register-center {
                margin-left: auto;
                margin-right: auto;
            }
            .register-title {
                width: 150px;
                margin-left: auto;
                margin-right: auto;
            }
            
            input {
               width: 100%;
               margin: 10px 0px 0px 0px;
               padding: 10px;
            }
        </style>
    </head>
    
    <body>
        <div class="register-wrapper register-center">
            <p class="register-title">Add Contact Form</p>
            <form action="add_contact_action.php" method="POST">
                <input type="text" name="firstName" value="" placeholder="First Name"/> <br>
                <input type="text" name="lastName" value="" placeholder="Last Name"/> <br>
                <input type="text" name="address" value="" placeholder="Address"/> <br>
                <?php
                    if( isset($_GET['greska']) ) {
                        $greska = $_GET['greska'];
                        if($greska == 1) {
                            echo '<p style="color: red">Edno od polinata go izostavivte</p>';
                        } else if($greska == 2) {
                            echo '<p style="color: red">Ne se validni informaciite</p>';
                        } else if($greska == 3) {
                            echo '<p style="color: red">Vnesenite parametri se gresni</p>';
                        }
                    }
                ?>
                <input type="submit" value="Add Contact"/>
            </form>
        </div>
    </body>
</html>