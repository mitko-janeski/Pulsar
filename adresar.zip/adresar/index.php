<?php

session_start();

if( isset($_SESSION['user']) ) {
    echo "Dobro dojde: " . $_SESSION['user']['first_name'] . 
            '<a href="logout.php">Log Out</a>';
} else {
    header('location: login.php');
}
$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING);
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);
if( !$page ) {
    $page = 1;
}
?>

<html>
    <head>
        <title>Index - Adresar</title>
        
        <style type="text/css">
            .index-wrapper {
                width: 800px;
                height: 500px;
                border: 1px solid black;
                margin-top: 100px;
            }
            .index-center {
                margin-left: auto;
                margin-right: auto;
            }
            .index-title {
                width: 100px;
                margin-left: auto;
                margin-right: auto;
            }
            
            input {
               width: 50%;
               margin: 10px 0px 0px 0px;
               padding: 10px;
               float: left;
            }
        </style>
    </head>
    
    <body>
        <div class="index-wrapper index-center">
            <p><a style="float: right;" href="add_contact.php">Add Contact</a></p>
            <div style="clear: both;">
                <form action="index.php" method="GET">
                    <input type="text" name="search" value="<?php echo $search; ?>" placeholder="Contact detail" />
                    <input type="hidden" name="page" value="<?php echo $page; ?>" />
                    <input type="submit" value="Search" />
                </form>
            </div>
            <table border="1" style="width:100%">
                <tr>
                    <th>First name</th>
                    <th>Last name</th> 
                    <th>Address</th>
                    <th>Action</th>
                </tr>
                <?php 
                
                    $limit = 5;
                    $offset = 0;
                    
                    if( $page > 0 ) {
                        $offset = ($page * $limit) - $limit;
                    }
                    
                    $link = mysqli_connect("localhost", "root", "", "adresar");
                    $query = "SELECT * FROM contacts WHERE user_id=" . $_SESSION['user']['user_id'] . " AND (first_name LIKE '%$search%' OR last_name LIKE '%$search%')"
                            . " LIMIT $limit OFFSET $offset";
                    $result = mysqli_query($link, $query);
                    $contacts = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    foreach($contacts as $key => $value) {
                        echo '<tr>
                                <td>'. $value['first_name'] .'</td>
                                <td>'. $value['last_name'] .'</td> 
                                <td>'. $value['address'] .'</td>
                                <td><a href="edit_contact.php?contact_id='. $value['contact_id'] .'">EDIT</a> <a href="delete_contact.php?contact_id='. $value['contact_id'] .'">DELETE</a></td>
                            </tr>';
                    }
                    
                    $query = "SELECT COUNT(user_id) as rows FROM contacts "
                            . "WHERE user_id=" . $_SESSION['user']['user_id'] . " AND (first_name LIKE '%$search%' OR last_name LIKE '%$search%')";
                    $result = mysqli_query($link, $query);
                    $contactCount = mysqli_fetch_assoc($result);
                    $contactCount = $contactCount['rows'];
                ?>
            </table>
            <?php
                $pages = ceil( $contactCount / $limit );
                if($page > 1) {
                    echo '<a href="index.php?page='. ($page-1) .'&search='. $search .'">Prev</a> ';
                }
                for($i = 1; $i <= $pages; $i++){
                    if( $page == $i ) {
                        echo $i . ' ';
                    } else {
                        echo '<a href="index.php?page='. $i .'&search='. $search .'">' . $i . '</a> ';
                    }
                }
                if($page < $pages) {
                    echo '<a href="index.php?page='. ($page+1) .'&search='. $search .'">Next</a> ';
                }
            ?>
        </div>
    </body>
</html>















